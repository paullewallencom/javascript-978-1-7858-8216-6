Chapter 1,  2, and 11 don't have code files. 

This book is ideal for JavaScript developers who want to gain expertise in object oriented programming with JavaScript and the new capabilities of ES-2015 to improve 
their web development skills and build professional-quality web applications.

You can refer to the following books for more information on coding with JavaScript:

1. Reactive Programming with JavaScript: https://www.packtpub.com/application-development/reactive-programming-javascript

2. Functional Programming in JavaScript: https://www.packtpub.com/web-development/functional-programming-javascript

3. Mastering JavaScript: https://www.packtpub.com/web-development/mastering-javascript