"use strict";
var consts = Object.freeze({ pi : 3.141});
consts.pi = 7;
