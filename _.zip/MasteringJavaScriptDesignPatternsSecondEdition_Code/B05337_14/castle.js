class Castle {
    constructor(name) {
        this.name = name;
    }
    Build() {
        console.log("Castle built: " + this.name);
    }
}
