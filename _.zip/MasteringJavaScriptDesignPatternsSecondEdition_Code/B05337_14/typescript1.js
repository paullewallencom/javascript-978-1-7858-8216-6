var numbers = [];
numbers.push(7);
numbers.push(9);
var unknown = numbers.pop();
console.log(unknown.substr(0, 1));
