"use strict";

if (true) {
	var outside = 9;
	var _inside = 7;
}

console.log(outside);
console.log(inside);

